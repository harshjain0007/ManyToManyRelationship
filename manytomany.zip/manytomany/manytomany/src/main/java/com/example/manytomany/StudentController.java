package com.example.manytomany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private StudentServices studentServices;

	@PostMapping
	public ResponseEntity<Student> save(@RequestBody Student student) {
		return ResponseEntity.ok(studentServices.save(student));
	}

	@GetMapping
	public ResponseEntity<Iterable<Student>> list() {
		return ResponseEntity.ok(studentServices.list());
	}

	@DeleteMapping("{id}")
	public void deleteByID(@PathVariable Integer id){
		studentServices.delete(id);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable Integer id, @RequestBody Student student) {
		Student updatedStudent = studentServices.updateStudent(id, student);
		return ResponseEntity.ok(updatedStudent);
	}

}
