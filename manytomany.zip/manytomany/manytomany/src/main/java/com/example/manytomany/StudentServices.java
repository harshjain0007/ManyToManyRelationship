package com.example.manytomany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentServices {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private SkillRepository skillRepository; // If needed for fetching skills


	public Student save(Student student) {
		return studentRepository.save(student);
	}

	public Iterable<Student> list() {
		return studentRepository.findAll();
	}

	public void delete(Integer id) {
		studentRepository.deleteById(id);
	}
	public Student updateStudent(Integer id, Student studentDetails) {
		Optional<Student> optionalStudent = studentRepository.findById(id);

		if (optionalStudent ==null) {
			return null;
		}

		Student student = optionalStudent.get();
		student.setFirstName(studentDetails.getFirstName());
		student.setLastName(studentDetails.getLastName());

		// Clear current skills and set new ones
		student.getSkills().clear();
		for (Skill skill : studentDetails.getSkills()) {
			// Optionally fetch existing skill by id
			Optional<Skill> existingSkill = skillRepository.findById(skill.getId());
			existingSkill.ifPresent(student.getSkills()::add); // Add only if skill exists
		}

		return studentRepository.save(student);
	}
}



